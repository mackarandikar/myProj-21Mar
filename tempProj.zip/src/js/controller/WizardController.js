app.controller('wizardController', ['$scope', 'Upload', '$timeout','$http','$rootScope', '$state', function ($scope, Upload, $timeout, $http, $rootScope, $state) {

    //Upload Email Auto Process// to be moved to pop-up
	$scope.getSelectedFileNames = function(files) 
	{

	}
    //

}]);